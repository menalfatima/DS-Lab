#include <iostream>
using namespace std;

struct Node {
    string name;
    int priority;
    Node* next;
};

class BookQueue {
private:
    Node* head;
    string bookName;

public:
    BookQueue(string bName) {
        head = NULL;
        bookName = bName;
    }

    void addStudent(string name, int priority) {
        Node* newNode = new Node{ name, priority, NULL };

        if (head == NULL || priority > head->priority) {
            newNode->next = head;
            head = newNode;
        }
        else {
            Node* temp = head;
            while (temp->next != NULL && temp->next->priority >= priority) {
                temp = temp->next;
            }
            newNode->next = temp->next;
            temp->next = newNode;
        }

        cout << name << " added to " << bookName << " queue.\n";
    }

    void removeStudent(string name) {
        if (head == NULL) {
            cout << "Queue empty.\n";
            return;
        }

        if (head->name == name) {
            Node* temp = head;
            head = head->next;
            delete temp;
            cout << name << " removed.\n";
            return;
        }

        Node* temp = head;
        while (temp->next != NULL && temp->next->name != name) {
            temp = temp->next;
        }

        if (temp->next == NULL) {
            cout << name << " not found.\n";
        }
        else {
            Node* del = temp->next;
            temp->next = del->next;
            delete del;
            cout << name << " removed.\n";
        }
    }

    void updatePriority(string name, int newPriority) {
        removeStudent(name);       
        addStudent(name, newPriority); 
        cout << name << " priority updated.\n";
    }

    void display() {
        cout << "\nBook: " << bookName << endl;

        if (head == NULL) {
            cout << "No reservations.\n";
            return;
        }

        Node* temp = head;
        while (temp != NULL) {
            cout << temp->name << "(P" << temp->priority << ") -> ";
            temp = temp->next;
        }
        cout << "NULL\n";
    }

    int countStudents() {
        int count = 0;
        Node* temp = head;

        while (temp != NULL) {
            count++;
            temp = temp->next;
        }
        return count;
    }

    void serveNext() {
        if (head == NULL) {
            cout << "No students waiting.\n";
            return;
        }

        Node* temp = head;
        cout << head->name << " got the book (" << bookName << ").\n";
        head = head->next;
        delete temp;
    }
};

int main() {

    BookQueue book1("Data Structures");
    BookQueue book2("Operating Systems");

    book1.addStudent("Ali", 2);
    book1.addStudent("Sara", 3);
    book1.addStudent("Ahmed", 1);

    book2.addStudent("Zara", 1);
    book2.addStudent("Usman", 3);
    book2.addStudent("Hina", 2);

    book1.display();
    book2.display();

    cout << "\nTotal (DS): " << book1.countStudents() << endl;
    cout << "Total (OS): " << book2.countStudents() << endl;

    book1.updatePriority("Ahmed", 3);

    book2.removeStudent("Zara");

    book1.serveNext();

    book1.display();
    book2.display();

    return 0;
}