#include <iostream>
using namespace std;

struct Node {
    string name;
    Node* next;
};

class PatientQueue {
private:
    Node* head;

public:
    PatientQueue() {
        head = NULL;
    }

    void addPatient(string name) {
        Node* newNode = new Node;
        newNode->name = name;
        newNode->next = NULL;

        if (head == NULL) {
            head = newNode;
        }
        else {
            Node* temp = head;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
        cout << name << " added to queue.\n";
    }

    void removePatient(string name) {
        if (head == NULL) {
            cout << "Queue is empty.\n";
            return;
        }

        if (head->name == name) {
            Node* temp = head;
            head = head->next;
            delete temp;
            cout << name << " removed from queue.\n";
            return;
        }

        Node* temp = head;
        while (temp->next != NULL && temp->next->name != name) {
            temp = temp->next;
        }

        if (temp->next == NULL) {
            cout << name << " not found in queue.\n";
        }
        else {
            Node* del = temp->next;
            temp->next = del->next;
            delete del;
            cout << name << " removed from queue.\n";
        }
    }

    void display() {
        if (head == NULL) {
            cout << "Queue is empty.\n";
            return;
        }

        Node* temp = head;
        cout << "Patients in queue:\n";
        while (temp != NULL) {
            cout << temp->name << " -> ";
            temp = temp->next;
        }
        cout << "NULL\n";
    }

    int countPatients() {
        int count = 0;
        Node* temp = head;

        while (temp != NULL) {
            count++;
            temp = temp->next;
        }
        return count;
    }
};

int main() {
    PatientQueue pq;

    pq.addPatient("Ali");
    pq.addPatient("Sara");
    pq.addPatient("Ahmed");

    pq.display();

    cout << "Total Patients: " << pq.countPatients() << endl;

    pq.removePatient("Sara");

    pq.display();

    cout << "Total Patients: " << pq.countPatients() << endl;

    return 0;
}