#include <iostream>
using namespace std;

class Employee {
public:
    virtual double calculateSalary() = 0;
};

class FullTimeEmployee : public Employee {
private:
    double fixedSalary;
public:
    FullTimeEmployee(double salary) {
        fixedSalary = salary;
    }

    double calculateSalary() {
        return fixedSalary;
    }
};

class PartTimeEmployee : public Employee {
private:
    double hoursWorked;
    double hourlyRate;
public:
    PartTimeEmployee(double hours, double rate) {
        hoursWorked = hours;
        hourlyRate = rate;
    }

    double calculateSalary() {
        return hoursWorked * hourlyRate;
    }
};

int main() {
    FullTimeEmployee f(50000);
    PartTimeEmployee p(20, 500);

    cout << "Full Time Employee Salary: " << f.calculateSalary() << endl;
    cout << "Part Time Employee Salary: " << p.calculateSalary() << endl;

    return 0;
}